package br.com.microservice.fornecedor.modelo;

public enum Tamanho {
	P, M, G;

}
