package br.com.microservice.fornecedor.modelo;

public enum Cor {
	PRETO, BRANCO, ROSA, AZUL, VERDE, AMARELO, VERMELHOR, ROXO;

}
