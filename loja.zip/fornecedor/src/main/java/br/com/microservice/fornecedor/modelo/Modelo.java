package br.com.microservice.fornecedor.modelo;

public enum Modelo {
	VESTIDO, BLUSA, CALÇA, CAMISETA, PIJAMA, SAIA,
}
