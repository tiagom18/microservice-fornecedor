package br.com.microservice.fornecedor.modelo;


public enum Status {
    RECEBIDO, PRONTO, ENVIADO;
}